document.addEventListener("DOMContentLoaded", () => {
    fetch('https://raw.githubusercontent.com/Turrens/PAC5/main/data.xml')
      .then(response => response.text())
      .then(xmlText => {
        const parser = new DOMParser();
        const xml = parser.parseFromString(xmlText, "application/xml");
        loadMenu(xml);
      })
      .catch(error => console.error("Error al cargar el XML:", error));
  });
  
  function loadMenu(xml) {
    const menu = document.getElementById("menu");
  
    // Recorro cada <GRUP> en el XML
    const groups = xml.getElementsByTagName("GRUP");
    for (let i = 0; i < groups.length; i++) {
      const group = groups[i];
  
      // Crear contenedor de sección
      const section = document.createElement("section");
      section.classList.add("section");
  
      // Alternar colores de fondo
      if (i % 2 === 1) {
        section.classList.add("alt-background");
      }
  
      // Añado contenedor para el texto y la imagen
      const contentWrapper = document.createElement("div");
      contentWrapper.classList.add("content-wrapper");
  
      // Añado título del grupo
      const groupName = document.createElement("h2");
      groupName.classList.add("section-title");
      groupName.textContent = group.getElementsByTagName("NOM")[0].textContent;
      contentWrapper.appendChild(groupName);
  
      // Añado platos
      const dishes = group.getElementsByTagName("PLAT");
      for (let j = 0; j < dishes.length; j++) {
        const dish = dishes[j];
  
        const dishContainer = document.createElement("div");
        dishContainer.classList.add("dish");
  
        const dishName = document.createElement("h3");
        dishName.classList.add("dish-name");
        dishName.textContent = dish.getElementsByTagName("NOM")[0].textContent;
        dishContainer.appendChild(dishName);
  
        const dishDescription = document.createElement("p");
        dishDescription.classList.add("dish-description");
        dishDescription.textContent = dish.getElementsByTagName("DESCRIPCIO")[0].textContent;
        dishContainer.appendChild(dishDescription);
  
        const dishPrice = document.createElement("p");
        dishPrice.classList.add("dish-price");
        dishPrice.textContent = `${dish.getElementsByTagName("PREU")[0].textContent} €`;
        dishContainer.appendChild(dishPrice);
  
        contentWrapper.appendChild(dishContainer);
      }
  
     
      const sectionImage = document.createElement("img");
      sectionImage.classList.add("section-image");
      sectionImage.src = `images/section-${i + 1}.jpg`; 
      sectionImage.alt = `Imagen del grupo ${i + 1}`;
      section.appendChild(contentWrapper);
      section.appendChild(sectionImage);
  
      menu.appendChild(section);
    }
  }
  